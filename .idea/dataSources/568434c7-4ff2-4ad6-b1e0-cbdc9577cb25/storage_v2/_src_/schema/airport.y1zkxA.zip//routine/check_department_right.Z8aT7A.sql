create function check_department_right(user_dep_id varchar(32), data_dep_id varchar(32)) returns tinyint(1)
BEGIN
-- 传入参数  user_dep_id 当前操作用户所属部门id ,
--           data_dep_id 需要检查当前用户是否有操作权限的部门id
declare flag TINYINT(1);	
 set flag=FIND_IN_SET(data_dep_id,get_children_dep(user_dep_id));
if flag=0 THEN
   return 0;
ELSE
   return 1;
end if;

END;

