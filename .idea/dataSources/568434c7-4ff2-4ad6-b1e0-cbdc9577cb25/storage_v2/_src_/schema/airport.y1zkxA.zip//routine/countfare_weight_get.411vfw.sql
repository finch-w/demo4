create procedure countfare_weight_get(IN currentUserId varchar(32), IN headid varchar(32), IN tabletype tinyint(1),
                                      IN weight double, INOUT customerRate double, INOUT minMoney double,
                                      INOUT flagweight tinyint(1), INOUT flagerrmsg varchar(255),
                                      OUT alertflag tinyint(1), OUT alertmessage varchar(255), OUT nowweight double,
                                      OUT autochange varchar(10))
BEGIN

-- headid 重量头id
-- tabletype 政策类别  1 航空公司总体政策 2 航空公司单议政策 3 航空公司中转运价政策 4 客户总体政策 5 客户分组政策 6 客户个别特殊政策 7 客户中转运价政策
-- weight   计费重量
-- customerRate 费率
-- minMoney  最低收费
-- flagweight 重量等级抓取 -- 0 未找到值  1找到值 ，为防止重量等级输入错误，便如全为空白，未输入值
-- flagerrmsg 错误信息回传

declare typeNum int ;
declare typeNum_ls int;

declare messageHead varchar(30);
declare nextrate double; -- 下一级费率
declare nextweight double; -- 如果重量级别上靠，则此为下一级别起始重量，如果重量不上靠将原重量写入 如果上靠级时要将重量改写为此重量，后续需求，需要依据航空公司设定是否可以费率上靠但重量不上靠，现均要改重量
declare ZHENGDAN_RATE_UP varchar(10); -- 正单是否自动上靠费率  tabletype 为1，2，3 时有效
declare  DAIDAN_RATE_UP  varchar(10); -- 代单是否自动上靠费率  tabletype  为 4，5，6，7 时有效
declare  userDepatId varchar(32); -- 当前用户部门id
declare  userRootDepartId varchar(32); -- 当前用户对应的公司id
declare oldrate double; -- 靠级前费率
set nowweight=0.00;

-- declare alertmessage varchar(255) ; -- 用于在在当前页面显示信息提配当前费率是否为自动上靠乖信息


-- set flagweight=0; -- 初始化


 drop table if exists tmp_pol_weight_level;
 CASE tabletype
		WHEN 1 THEN  -- 1 航空公司总体政策				
				  create temporary table tmp_pol_weight_level 
									select pol.id,pol.head_id,weight.code weight_code,pol.feeRate,weight.WEIGHT_START,weight.WEIGHT_end,weight.TYPE_NUM
									  from pol_domestic_airways_commons pol,
										     base_weight_level weight
										where pol.head_id=headid 
										  and pol.weight_id=weight.id
											order by weight.TYPE_NUM;	
						set messageHead="航空公司总体政策";
				
		WHEN 2 THEN -- 2 航空公司单议政策
				create temporary table tmp_pol_weight_level 
									select pol.id,pol.head_id,weight.code weight_code,pol.feeRate,weight.WEIGHT_START,weight.WEIGHT_end,weight.TYPE_NUM
									  from pol_domestic_airways_dy pol,
										     base_weight_level weight
										where pol.head_id=headid 
										  and pol.weight_id=weight.id
											order by weight.TYPE_NUM;	
						set messageHead="航空公司单议政策";
				
		WHEN 3 THEN  -- 3 航空公司中转运价政策
				 create temporary table tmp_pol_weight_level 
									select pol.id,pol.head_id,weight.code weight_code,pol.feeRate,weight.WEIGHT_START,weight.WEIGHT_end,weight.TYPE_NUM
									  from pol_domestic_airways_zz pol,
										     base_weight_level weight
										where pol.head_id=headid 
										  and pol.weight_id=weight.id
											order by weight.TYPE_NUM;	
				     set messageHead="航空公司中转运价政策";
						 
		WHEN 4 THEN  --  4 客户总体政策
				 create temporary table tmp_pol_weight_level 
									select pol.id,pol.head_id,weight.code weight_code,pol.feeRate,weight.WEIGHT_START,weight.WEIGHT_end,weight.TYPE_NUM
									  from pol_domestic_cus_commons pol,
										     base_weight_level weight
										where pol.head_id=headid 
										  and pol.weight_id=weight.id
											order by weight.TYPE_NUM;		
				     set messageHead="客户总体政策";
						 
			-- select * from tmp_pol_weight_level;
			
		WHEN  5 THEN -- 5 客户分组政策
				 create temporary table tmp_pol_weight_level 
									select pol.id,pol.head_id,weight.code weight_code,pol.feeRate,weight.WEIGHT_START,weight.WEIGHT_end,weight.TYPE_NUM
									  from pol_domestic_cus_group pol,
										     base_weight_level weight
										where pol.head_id=headid 
										  and pol.weight_id=weight.id
											order by weight.TYPE_NUM;	
							set messageHead="客户分组政策";		
					-- select * from 		tmp_pol_weight_level;		
											
		WHEN 6 THEN  -- 6 客户个别特殊政策
		        create temporary table tmp_pol_weight_level 
									select pol.id,pol.head_id,weight.code weight_code,pol.feeRate,weight.WEIGHT_START,weight.WEIGHT_end,weight.TYPE_NUM
									  from pol_domestic_cus_special pol,
										     base_weight_level weight
										where pol.head_id=headid 
										  and pol.weight_id=weight.id
											order by weight.TYPE_NUM;		
							set messageHead="客户个别特殊政策";		
				-- select * from 		tmp_pol_weight_level;
				
		WHEN 7 THEN   -- 7 客户中转运价政策
				create temporary table tmp_pol_weight_level 
									select pol.id,pol.head_id,weight.code weight_code,pol.feeRate,weight.WEIGHT_START,weight.WEIGHT_end,weight.TYPE_NUM
									  from pol_domestic_cus_zz pol,
										     base_weight_level weight
										where pol.head_id=headid 
										  and pol.weight_id=weight.id
											order by weight.TYPE_NUM;		
						 set messageHead="客户中转运价政策";					
		ELSE
				set flagweight=0;
			  set flagerrmsg="政策类型有误，请通知开发人员！";
end case  ;




  	  select feeRate into minMoney from tmp_pol_weight_level where trim(weight_code)='M';  --  取得最低收费
			
		
			
			select feeRate ,TYPE_NUM into customerRate, typeNum     -- 取得计费重量所处于的费率及重量等级序号
			        from tmp_pol_weight_level  
						where trim(weight_code)<>'M'
						  and weight between WEIGHT_START and WEIGHT_end;
							
				set typeNum_ls=typeNum;
				-- select typeNum_ls;
				
			-- 如果此重量等级序号费率为空				
			if ((customerRate is null  || customerRate=0) && typeNum_ls>2) then   -- typeNum 为1  因为最低收费项不在取数范围内		
	
		-- select typeNum;	
				 myloop:loop                                               -- 循环往上一级进行取费率，即向小重量级取费率
					 set typeNum_ls=typeNum_ls-1;
					 select feeRate into customerRate from tmp_pol_weight_level where type_num=typeNum_ls;
					 if ( customerRate>0 || typeNum_ls<2) then					 
					      leave myloop;
				   end if;      
				end loop myloop; 
			
			end if;
			
			
			-- 取得下一重量级费率 及起始重量 作为计算是否上靠级别依据
			select feeRate ,WEIGHT_START into nextrate,nextweight from tmp_pol_weight_level where type_num=typeNum+1;
			
			
			
			-- 取得当前用户对应的公司id
			select depid into  userDepatId from qx_users where id=currentUserId;
			select get_root_department_id(userDepatId) into userRootDepartId;
			
			-- 判断 当前typeNum费率*重量 是否大于typeNum+1 的费率*重量 
			-- 如无下一级费或下级费率为空则不用计算
			-- 如系统参数找不到时则默认为关闭			
			
			if find_in_set(tabletype,'1,2,3') then  -- 正单判断
			
					select para_value into ZHENGDAN_RATE_UP  from base_parameters where depart_id=userRootDepartId and para_code='ZHENGDAN_RATE_UP';
				
					if (ISNULL(ZHENGDAN_RATE_UP) || LENGTH(trim(ZHENGDAN_RATE_UP))<1) then
							set ZHENGDAN_RATE_UP='OFF';
					end if;        
					
					if ( nextrate is not null && customerRate is not null ) then  -- 如果下一级别费率是空的话则费率与本级相同，则不存在重量上靠问题
																																			  -- 如果当前费率为空时，因上面已进行循环取前则表示本次取值失败
					
							if (customerRate*weight>nextrate*nextweight) then   
							-- 如果下一级费用费率*起始重量低于当前费率*当前重量时，则表示需要靠级处理，
									if (ZHENGDAN_RATE_UP='ON') then
									-- 如果系统设定为要自动靠级，则将当前费率写入oldrate，下一级别费率替换当前费率,当前重量写为下一级起始重量
									
											set oldrate=customerRate;
											set customerRate=nextrate;
											set nowweight=nextweight;
											set alertflag=1;-- 需要页面警示
											
											set alertmessage=concat('费率已自动上靠级别，靠级前费率为：',oldrate,'  靠级前计费重量为：',weight);
									else
									-- 如果不自动靠级，则提示需要靠级的费率及靠级重量，需要营业员手动调整
									-- customerRate 不变 nowweight 为保留当前weight,提示nextweight
										  set nowweight=weight;
										  set alertflag=1 ; -- 需要页面警示
											set alertmessage=concat('请确认是否上靠级别，上靠费率为：',nextrate,'  上靠计费重量为：',nextweight);
									end if;
							 else
							 -- 不需要靠级处理
						   	     set alertflag=0 ; -- 需要页面警示
											set alertmessage=concat('正常');
							end if;
					else
					    -- 不需要靠级处理
							  set alertflag=0 ; -- 需要页面警示
								set alertmessage=concat('正常');	
					
					end if;

          set  autochange =ZHENGDAN_RATE_UP;
			
			end if;
			
			if find_in_set(tabletype,'4,5,6,7') then
			  
				select para_value into DAIDAN_RATE_UP  from base_parameters where depart_id=userRootDepartId and para_code='DAIDAN_RATE_UP';
				
					if (DAIDAN_RATE_UP  is null) then
							set DAIDAN_RATE_UP='OFF';
					end if;    
					
					if ( nextrate is not null && customerRate is not null ) then  -- 如果下一级别费率是空的话则费率与本级相同，则不存在重量上靠问题
																																			  -- 如果当前费率为空时，因上面已进行循环取前则表示本次取值失败
					
							if (customerRate*weight>nextrate*nextweight) then   
							-- 如果下一级费用费率*起始重量低于当前费率*当前重量时，则表示需要靠级处理，
									if (DAIDAN_RATE_UP='ON') then
									-- 如果系统设定为要自动靠级，则将当前费率写入oldrate，下一级别费率替换当前费率,当前重量写为下一级起始重量
									
											set oldrate=customerRate;
											set customerRate=nextrate;
											set nowweight=nextweight;
											set alertflag=1;-- 需要页面警示
											
											set alertmessage=concat('费率已自动上靠级别，靠级前费率为：',oldrate,'  靠级前计费重量为：',weight);
									else
									-- 如果不自动靠级，则提示需要靠级的费率及靠级重量，需要营业员手动调整
									-- customerRate 不变 nowweight 为保留当前weight,提示nextweight
										  set nowweight=weight;
										  set alertflag=1 ; -- 需要页面警示
											set alertmessage=concat('请确认是否上靠级别，上靠费率为：',nextrate,'  上靠计费重量为：',nextweight);
									end if;
							 else
							 -- 不需要靠级处理
						   	     set alertflag=0 ; -- 需要页面警示
											set alertmessage=concat('正常');
							end if;
					else
					    -- 不需要靠级处理
							  set alertflag=0 ; -- 需要页面警示
								set alertmessage=concat('正常');	
					
					end if;

					set  autochange =DAIDAN_RATE_UP;
			end if;


		 set flagweight=1;
		-- (ISNULL(minMoney) || LENGTH(trim(minMoney))<1)
			if(minMoney is null || minMoney=0) then
			   set minMoney=0;
			   set flagweight=0;
			   set flagerrmsg=CONCAT(messageHead,"最低收费标准错误，请查证！");		
			
			end if;
			
			if (customerRate is null  || customerRate=0) then
			  set customerRate=0;
			   set flagweight=0;
			   set flagerrmsg=CONCAT(messageHead,"重量等级存在但无对应费率，请查证！");
				 
				
			end if;
			
	


END;

