create function get_user_dep_airwaysrateall(user_dep_id varchar(32)) returns tinyint(1)
BEGIN
		#Routine body goes here...
-- 传入当前部门id ,取得其部门及其各下级部门负责出港，进港业务的合集，都包括为通用
 declare airwaysrate integer default 8 ;  -- 存取循环值 
 declare airwaysrate_0 integer default 0;
 declare airwaysrate_1 integer default 0;

 declare  airwaysrateall integer default 3; -- 得到最后值 3为出错
 declare no_more integer DEFAULT 0;



  DECLARE airwaysrate_list CURSOR FOR   select distinct a.airways_rate from qx_department a where FIND_IN_SET(a.id,get_children_dep(user_dep_id));

 
   DECLARE CONTINUE HANDLER FOR NOT FOUND  SET no_more = 1;
   
   OPEN airwaysrate_list;
  
   FETCH airwaysrate_list INTO airwaysrate;


	if no_more = 1 then 
			 RETURN 3; 

	 ELSE

			  WHILE !no_more DO


            if airwaysrate=0 THEN set airwaysrate_0=1; end if;
            if airwaysrate=1 then set airwaysrate_1=1; end if;
          

					set no_more=0; -- 防mysql bug
					FETCH airwaysrate_list INTO airwaysrate;


				
				 END WHILE;
				 CLOSE airwaysrate_list;
   end if;	

 
	if (airwaysrate_0=0 && airwaysrate_1=1) then set airwaysrateall=1; end if;
	if (airwaysrate_0=1 && airwaysrate_1=0) then set airwaysrateall=0; end if;
	if (airwaysrate_0=1 && airwaysrate_1=1) then set airwaysrateall=2; end if;

    
	

	RETURN airwaysrateall ;END;

