create function menu_allow(check_resource varchar(50), allow_type varchar(50)) returns char
  comment '检测当前资源，及各下级菜单中是否有相对移动端或pc电脑端权限'
BEGIN
-- allow_type  'app  是否有移动端菜单权限 ‘pc' 是否有电脑端权限
 
   declare end_res varchar(1);

    set max_sp_recursion_depth=12; -- 最大遍历12层
   call menu_allow_type_check(check_resource,allow_type,@e_status);   
  
    select @e_status into end_res;

	RETURN end_res;
END;

