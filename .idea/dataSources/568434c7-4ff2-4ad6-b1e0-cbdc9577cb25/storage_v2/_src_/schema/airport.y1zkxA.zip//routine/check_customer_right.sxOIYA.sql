create function check_customer_right(user_dep_id varchar(32), cust_group_id varchar(32)) returns tinyint(1)
BEGIN
-- 传入参数 user_dep_id 当前操作用户所属部门id
--         cust_group_id 当前客户所属分组id

declare flag TINYINT(1);	
declare data_dep_id varchar(32);

 select department_id into data_dep_id from base_customer_group where id=cust_group_id;
 set flag=FIND_IN_SET(data_dep_id,get_children_dep(user_dep_id));
if flag=0 THEN
   return 0;
ELSE
   return 1;
end if;

END;

