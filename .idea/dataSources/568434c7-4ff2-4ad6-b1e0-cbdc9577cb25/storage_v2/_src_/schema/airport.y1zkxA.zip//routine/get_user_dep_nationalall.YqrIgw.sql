create function get_user_dep_nationalall(user_dep_id varchar(32)) returns tinyint(1)
BEGIN
	#Routine body goes here...
-- 传入当前部门id ,取得其部门及其各下级部门负责国内，国外业务的合集，都包括为通用
 declare national integer default 8 ;  -- 存取循环值 
 declare national_0 integer default 0;
 declare national_1 integer default 0;
 declare national_2 integer default 0;
 declare  nationalall integer default 3; -- 得到最后值 3为出错
 declare no_more integer DEFAULT 0;



  DECLARE national_list CURSOR FOR   select distinct a.national from qx_department a where FIND_IN_SET(a.id,get_children_dep(user_dep_id));
 --       select distinct a.national  from qx_department a ,(select get_children_dep(user_dep_id) department_id from dual ) b   where FIND_IN_SET(a.id,b.department_id);



-- select distinct national from qx_department where FIND_IN_SET(id,get_children_dep(user_dep_id));
 
   DECLARE CONTINUE HANDLER FOR NOT FOUND  SET no_more = 1;
   
   OPEN national_list;
  
   FETCH national_list INTO national;


	if no_more = 1 then 
			 RETURN 3; 

	 ELSE

			  WHILE !no_more DO


            if national=0 THEN set national_0=1; end if;
            if national=1 then set national_1=1; end if;
            if national=2 then set national_2=1; end if;   

					set no_more=0; -- 防mysql bug
					FETCH national_list INTO national;


				
				 END WHILE;
				 CLOSE national_list;
   end if;	

  if (national_2=1) then set nationalall=2; end if;
	if (national_2=0 && national_0=0 && national_1=1) then set nationalall=1; end if;
	if (national_2=0 && national_0=1 && national_1=0) then set nationalall=0; end if;
	if (national_2=0 && national_0=1 && national_1=1) then set nationalall=2; end if;

    
	

	RETURN nationalall ;

END;

