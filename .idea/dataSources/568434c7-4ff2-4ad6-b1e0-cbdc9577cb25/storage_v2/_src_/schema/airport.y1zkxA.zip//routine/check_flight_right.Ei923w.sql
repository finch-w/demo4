create function check_flight_right(user_dep_id varchar(32), national tinyint(1),
                                   flightproperty tinyint(1)) returns tinyint(1)
BEGIN
	-- 传入参数 user_dep_id 当前操作用户所属部门id
--         national 当前 航班范围（0：国内 1：国际  2 ：通用）',
--         flightproperty  航班性质  （0 到港航班  1 出港航班）',

declare flag INTEGER DEFAULT 0;	
-- 到得当前用户所属部门 航班范围及航班性质 --本处暂不取各下级权限汇总，因为配载也维护国外的
declare dep_national tinyint(1);
declare dep_flightproperty tinyint(1);

select NATIONAL,PROPERTY into dep_national,dep_flightproperty from qx_department where id=user_dep_id;

case  
    when (dep_national=national && dep_flightproperty=flightproperty)  then  set flag=1;
    when (dep_national=2 && dep_flightproperty=flightproperty)  then set flag=1;
    when (dep_national=2 && dep_flightproperty=2)  then set flag=1;
    when (dep_national=national && dep_flightproperty=2)  then  set flag=1;
else set flag=0;
end case;

if flag=0 THEN
   return 0;
ELSE
   return 1;
end if;
END;

