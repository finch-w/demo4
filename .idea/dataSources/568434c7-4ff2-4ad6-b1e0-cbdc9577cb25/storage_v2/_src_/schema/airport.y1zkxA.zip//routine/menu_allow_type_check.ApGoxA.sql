create procedure menu_allow_type_check(IN check_resource varchar(50), IN allow_type varchar(50),
                                       OUT end_status varchar(1))
BEGIN
	
 
  declare no_more int default 0;  
  declare this_resourcename varchar(50);
  declare this_moduleid   varchar(10);
  declare this_persource varchar(50);
  declare this_state  varchar(10);
  declare this_type   varchar(50);
  declare this_app_allow varchar(1);
  declare this_pc_allow varchar(1);


 
 DECLARE current_res CURSOR FOR  select resourcename,moduleid,presource,state,type,app_allow,pc_allow
                                   from qx_resource where  PRESOURCE=check_resource;

  DECLARE CONTINUE HANDLER FOR NOT FOUND  SET no_more = 1;	

 
  OPEN current_res;
  
  FETCH current_res INTO this_resourcename,this_moduleid,this_persource,this_state,this_type,this_app_allow,this_pc_allow;
  
  if no_more = 1 then -- 到最后一层了

    -- select app_allow  into end_status from qx_resource where resourcename=  
     set end_status='0';

  ELSE
	   WHILE !no_more DO

        IF this_type='ACTION' THEN  -- 为最后一层且存在访问权限

            if allow_type='app'  THEN                
          
                if this_app_allow='1' then
									set end_status='1';
									set no_more=1;
                 ELSE
                  set end_status='0';
									set no_more=0; 
                end if;
             ELSE
               if allow_type='pc' then
									if this_pc_allow='1' then
										set end_status='1';
										set no_more=1;
                   ELSE
                     set end_status='0';
										set no_more=0;
									end if;
               end if;
             end if;

        ELSE    --  否则需要继续找他的下级

						  call menu_allow_type_check(this_resourcename,allow_type,@e_status);
              set end_status=@e_status;
						 
              if end_status=1 THEN  -- 如果遇到有1则直接返回退出即可
						 
               	 set no_more=1;
              ELSE
                  set no_more=0; 

						  end if;
        end if;

				FETCH current_res INTO this_resourcename,this_moduleid,this_persource,this_state,this_type,this_app_allow,this_pc_allow;

     END WHILE;
	   CLOSE current_res;
		-- select airways_id1;
  end if;


END;

