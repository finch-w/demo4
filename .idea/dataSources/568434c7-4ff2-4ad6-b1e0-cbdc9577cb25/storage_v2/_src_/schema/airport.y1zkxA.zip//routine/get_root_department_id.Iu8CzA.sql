create function get_root_department_id(user_dep_id varchar(32)) returns varchar(32)
BEGIN
-- 根据 指定department id 找到对应组织的根部门
	#Routine body goes here...
  DECLARE root_dep_id_ls varchar(32) default user_dep_id;
  declare f_dep_id  varchar(32); 
  declare root_dep_id varchar(32);
  
  WHILE root_dep_id_ls <>"ROOT"  do 
	    SET f_dep_id =(select par.id from qx_department cur,qx_department par where cur.parent=par.NAME and cur.id=root_dep_id_ls);
																		
			IF f_dep_id <>"ROOT" THEN 
        set root_dep_id=f_dep_id;
				SET root_dep_id_ls = f_dep_id; 
			ELSE
        set root_dep_id=root_dep_id_ls;
				SET root_dep_id_ls = f_dep_id;
			END IF; 

END WHILE; 
	RETURN root_dep_id ;
END;

