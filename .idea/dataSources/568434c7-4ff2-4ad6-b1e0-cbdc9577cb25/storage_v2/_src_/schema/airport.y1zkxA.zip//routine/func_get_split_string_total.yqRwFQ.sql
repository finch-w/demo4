create function func_get_split_string_total(f_string varchar(1000), f_delimiter varchar(5)) returns int
BEGIN
 -- 传入参数 ：字符串 分割符，
 --  传回分割 字符串数量值  
  return 1+(length(f_string) - length(replace(f_string,f_delimiter,'')));
END;

