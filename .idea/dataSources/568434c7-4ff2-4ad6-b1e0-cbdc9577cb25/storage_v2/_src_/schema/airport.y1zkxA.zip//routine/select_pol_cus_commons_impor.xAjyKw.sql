create procedure select_pol_cus_commons_impor()
begin
  declare airportId varchar(36);
  declare airportName varchar(100);
  select ID, concat(CNAME_SHORT, '/', CODE_THREE) into airportId,airportName
  from base_airport;
  select airportId;
#   select airportName;
end;

