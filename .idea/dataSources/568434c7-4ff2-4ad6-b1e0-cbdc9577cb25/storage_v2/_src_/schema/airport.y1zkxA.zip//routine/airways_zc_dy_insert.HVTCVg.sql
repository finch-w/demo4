create procedure airways_zc_dy_insert()
BEGIN
-- 依所传入档转航空公司单议运价政策

 DECLARE airways varchar(2);
 DECLARE start_airport varchar(3);
 DECLARE end_airport varchar(3);
 DECLARE flight_no varchar(6);
 DECLARE goods_type varchar(6);
 declare  m double ;
 declare  n double;
 declare  A45 double;
 declare  A100 double;
 declare  A300 double;
 declare  A500 double;
 declare  A1000 double;


 declare i int default 0;
 declare cnt int default 7;
 declare no_more integer DEFAULT 0;
 declare num integer default 0;

  declare aairway_id varchar(255); -- '航空公司',
 declare  agt_id longtext; -- '货物类型',
  declare aflight_id longtext ;-- '航班',

  declare  aport_city_id  varchar(255); -- '出港城市',
 declare  aarrive_city_id longtext;   -- '到港城市',
 declare  aweight_id varchar(255)  ;  -- '重量等级',
 declare  afeeRate double; -- '费率',
 declare  astart_date datetime  default DATE_FORMAT('2018-09-20','%Y-%m-%d') ;
 declare  aend_date datetime    ;
 declare  astatus int default 1 ; -- '状态码（有效1，无效0）',
 declare  ais_del int default 0 ;  -- '逻辑删除字段（1：已删除，0：未删除）',
 declare  acreateDate datetime default NOW();
 declare  amodifyDate datetime  ;
 declare  acreate_user_id varchar(255) default '402881a84423645b014423854aa80001' ;
declare   amodify_user_id varchar(255) ;
 declare  aset_code varchar(255) ;  -- '结算代码',
declare   aweight_type varchar(255) default '1'; -- '重量等级类别（1：航空公司类，2，配送类，3货代类）',
 declare  aflightType int(10) ; -- '航班标识（全部航班:''0''    适应航班:''1''''    不适应航班'':''2''）',

  

 DECLARE dy_import CURSOR FOR  select * from pol_domestic_airways_dy_import;
 
 DECLARE CONTINUE HANDLER FOR NOT FOUND  SET no_more = 1;

  
 OPEN dy_import;
  
 FETCH dy_import INTO airways,start_airport,end_airport,flight_no,goods_type,m,n,A45,A100,A300,A500,A1000;

if no_more = 1 then 
     select "no result"; 

 ELSE
	 WHILE !no_more DO
      
   --   insert into myls (f1,f2) VALUES( REPLACE(UUID(),'-',''),airways);
       
      select id into aairway_id from base_airways where trim(code_two)=trim(airways);

-- insert into myls (f1,f2) VALUES( REPLACE(UUID(),'-',''),airway_id);

      select id into agt_id from base_goods_type where good_code=goods_type;
      set  aflight_id=flight_no;
      SELECT id into aport_city_id from base_airport where code_three=start_airport;
      select id into aarrive_city_id from base_airport where code_three=end_airport;
     
      if aflight_id = '' then 
           set aflightType=0;
           set aflight_id='ALL';
      ELSE 
           set aflightType=1;
           
      end if;



			    set cnt = 7;
		
				 while i < cnt  do
						set i = i + 1;
						
         if i=1 then

								 select id into aweight_id from base_weight_level where type=aweight_type and code='M';
								 set afeerate=m;
         end if;
         if i=2 THEN
                  
									 select id into aweight_id from base_weight_level where type=aweight_type and code='N';
									 set afeerate=n;
         end if;
					if i=3 THEN
									select id into aweight_id from base_weight_level where type=aweight_type and code='+45';
									set afeerate=A45;
          end if;
					if i=4 THEN
									select id into aweight_id from base_weight_level where type=aweight_type and code='+100';
									set afeerate=A100;
          end if;
					if i=5 THEN
									select id into aweight_id from base_weight_level where type=aweight_type and code='+300';
									set afeerate=A300;
           end if;
						if i=6 THEN
										select id into aweight_id from base_weight_level where type=aweight_type and code='+500';
										set afeerate=A500;

            end if;
						if i=7 then

										select id into aweight_id from base_weight_level where type=aweight_type and code='+1000';
										set afeerate=A1000;
            end if;

             

									insert into pol_domestic_airways_dy_ls
							(id, airway_id, gt_id, flight_id, port_city_id, arrive_city_id, weight_id, feerate, start_date, end_date, status,
							 is_del, createdate, modifydate,  create_user_id,  modify_user_id, set_code, weight_type, flighttype) 
							values (REPLACE(UUID(),'-',''),aairway_id,agt_id,aflight_id,aport_city_id,aarrive_city_id,aweight_id,afeerate,astart_date,
							aend_date,astatus,ais_del,acreatedate,amodifydate,acreate_user_id,amodify_user_id,'',aweight_type,aflighttype);

					end WHILE;

        set no_more=0; -- 防mysql bug
				FETCH dy_import INTO airways,start_airport,end_airport,flight_no,goods_type,m,n,A45,A100,A300,A500,A1000;
				set i=0;
	 END WHILE;
	 CLOSE dy_import;
		-- select airways_id1;
end if;


END;

