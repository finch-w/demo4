create procedure goods_update()
BEGIN
 

 DECLARE id1 varchar(32);
 DECLARE goods_name1 varchar(255);
 DECLARE airways_id1 varchar(255);
 declare i int default 0;
 declare cnt int default 0;
declare  airways_id00 varchar(255);
declare  airways_idls varchar(255);
  
 declare no_more integer DEFAULT 0;

declare num integer default 0;

  -- 建表tb_temp1
--  DROP TABLE IF EXISTS tb_temp1;

 DECLARE cursor_goods CURSOR FOR  select * from ls;
 
 DECLARE CONTINUE HANDLER FOR NOT FOUND  SET no_more = 1;
-- DROP TABLE IF EXISTS tb_temp1;
-- CREATE TEMPORARY TABLE tb_temp1 select * from ls where 1=2;
  
 OPEN cursor_goods;
  
 FETCH cursor_goods INTO id1,goods_name1,airways_id1;

if no_more = 1 then 
     select "no result"; 

 ELSE
	 WHILE !no_more DO
    -- select  goods_name1;
			set cnt = func_get_split_string_total(airways_id1,",");
			set airways_id00="";
       set num=num+1;

				 while i < cnt  do
						set i = i + 1;

						select id into airways_idls from base_airways where replace(code_two,' ','')=replace( func_get_split_string(airways_id1,',',i),' ','');
						if i=1 THEN
						 set  airways_id00=airways_idls;
						else
						set  airways_id00=CONCAT_WS(',',airways_id00,airways_idls);
						 end if;
					end WHILE;



				INSERT INTO ls1 (id,goods_code,goods_name,airways_id) VALUES (REPLACE(UUID(),'-',''), CONCAT('A',LPAD(num, 3, 0)),goods_name1,airways_id00);


        set no_more=0; -- 防mysql bug
				FETCH cursor_goods INTO id1, goods_name1, airways_id1;
				set i=0;
	 END WHILE;
	 CLOSE cursor_goods;
		-- select airways_id1;
end if;




END;

