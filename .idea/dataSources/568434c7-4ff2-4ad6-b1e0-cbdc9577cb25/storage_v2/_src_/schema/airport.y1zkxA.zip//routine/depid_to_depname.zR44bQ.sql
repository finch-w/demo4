create function depid_to_depname(dep_ids varchar(10000)) returns varchar(10000)
  comment '将传入的一组部门id 转换为一组部门名称'
BEGIN
	-- 将传入的一组部门id 转换为一组部门名称

  declare i int default 0;
 declare no_more integer DEFAULT 0;


  declare dep_name_ls varchar(255);
  declare dep_name varchar(10000) default "";
 declare flag tinyint(1) default 0;

  -- DECLARE department_list CURSOR FOR  select a.name  from qx_department a where FIND_IN_SET(a.id,get_children_dep(dep_ids));
  DECLARE department_list CURSOR FOR  select a.name  from qx_department a where FIND_IN_SET(a.id,dep_ids);

  DECLARE CONTINUE HANDLER FOR NOT FOUND  SET no_more = 1;
   
  OPEN department_list;

  FETCH department_list INTO dep_name_ls;


	if no_more = 1 then 
			 RETURN ""; 

	 ELSE
       WHILE !no_more DO

     
           if flag=0 THEN
               set dep_name=dep_name_ls;

               set flag=1;
            ELSE
               set dep_name= CONCAT(dep_name,',',dep_name_ls);
               
            end if;


					set no_more=0; -- 防mysql bug
					 FETCH department_list INTO dep_name_ls;


				
				 END WHILE;
				 CLOSE department_list;


  end if;


	RETURN dep_name;
END;

