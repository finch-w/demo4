create procedure fronting_bill_countfare(IN currentUserId varchar(32), IN baseAirport varchar(32),
                                         IN customerId varchar(32), IN airlineId1 varchar(32),
                                         IN destination1 varchar(32), IN flightNo1 varchar(32),
                                         IN airlineId2 varchar(32), IN destination2 varchar(32),
                                         IN flightNo2 varchar(32), IN cargoType varchar(32), IN flighDate varchar(10),
                                         IN weight double, OUT customerRate double, OUT minMoney double,
                                         OUT flag tinyint(1), OUT flagerrmsg varchar(255), OUT alertflag tinyint(1),
                                         OUT alertmessage varchar(255), OUT nowweight double,
                                         OUT autochange varchar(10))
BEGIN

 -- baseAirport 基准机场
-- customerId 客户id
-- airlineId1第一航程航空公司id
-- destination1第一航程到港机场id
-- flightNo1第一航程航班
-- airlineId2第二航程航空公司id
-- destination2第二航程到港机场id
-- flightNo2第二航程航班
-- cargoType 货物类型
-- flighDate  第一航程起飞时时计算运价的基准日期
-- weight   计费重量
-- flag  -- 0 未找到值  1已找到值且正常

  declare  nocount int default 0;
	declare  headid varchar(32) default '0';
 
	declare  flagtype tinyint(1) default 0;   -- 0 未找到值 1 已找值  工与flag 配合使用，因有存在记录但异常，如重复
	declare  flagweight tinyint(1) default 0; -- 0 未找到值  1找到值 ，为防止重量等级输入错误，便如全为空白，未输入值

	set flag=0;
	set flagerrmsg="";
	set minMoney=0.00;
	set customerRate=0.00;
	set alertflag=0;
	
	-- 第二航程航空公司相同时要取中转运价政策中价格，如航空公司不同，提示第一段运费费率及请协调具体运费费率,手动进行填写并手动计算
	if ( ISNULL(airlineId2) || LENGTH(trim(airlineId2))<1 || airlineId2<>airlineId1) THEN
	
     	 -- 判断客户的个别特殊政策  pol_domestic_cus_special  pol_domestic_cus_special_head
			 if (flag=0 && flagtype=0) then
					-- 找单头
					 drop table if exists tmp_pol_cust_special;
					 create temporary table tmp_pol_cust_special 
										select * from pol_domestic_cus_special_head 
											where port_city_id=baseAirport 
												and (airway_id='ALL' or airway_id=airlineId1)
												and (arrive_city_id='ALL' or find_in_set(destination1,arrive_city_id))
												and (flight_id='ALL' or 
															((flightType=1 and find_in_set(flightNo1,flight_id)) or (flightType=2 and !find_in_set(flightNo1,flight_id)))
													 )
												 and (start_date is null or  
															 flighDate between date_format(start_date,'%Y-%m-%d') and  if ( end_date is null , '9999-12-31',date_format(end_date,'%Y-%m-%d')) 
															)	
												 and customer_id=customerId
												 and status=1
												 and is_del=0;
												 
							select count(*) into nocount from  tmp_pol_cust_special;		
					
			-- select  nocount;
							if nocount<>0 then   -- 有找到符合记录
							
								 if (nocount=1) then
										select id into headid from tmp_pol_cust_special;   -- 得到头id 以便后面取得单身生量等级资料		
									-- select headid;
								    call countfare_weight_get(currentUserId,headid,6,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
									-- select "aaaa";	
										
										if flagweight=1 then
											set flag=1;		
											set flagtype =1;	
											
											
											-- select customerRate;
											-- select minMoney;
										else
										   set flag=1;    -- 记录有找到
											 set flagtype=0; -- 值异常，未找到重量对应数据
									  end if;	
								 else  -- 如果有多条记录存在时，按 具体航班号 、航空公司 、具体货物品名 具体到站地点 的优先顺序取值 
									
										select id into headid from tmp_pol_cust_special where find_in_set(flightNo1,flight_id);
										
										-- select headid;
										
										if headid<>0 then
											 call countfare_weight_get(currentUserId,headid,6,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
												if flagweight=1 then
													set flag=1;		
													set flagtype =1;	
												else
													 set flag=1;    -- 记录有找到
													 set flagtype=0; -- 值异常，未找到重量对应数据
												end if;	
										else
											 select id into headid from tmp_pol_cust_special where find_in_set(airlineId1,airlineId1);
												if headid<>0 then
													call countfare_weight_get(currentUserId,headid,6,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
													if flagweight=1 then
														set flag=1;		
														set flagtype =1;	
													else
														 set flag=1;    -- 记录有找到
														 set flagtype=0; -- 值异常，未找到重量对应数据
													end if;	
												else								
														select id into headid from tmp_pol_cust_special where find_in_set(cargoType,CARGO_TYPE);
														 if headid<>0 then
																call countfare_weight_get(currentUserId,headid,6,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
																if flagweight=1 then
																	set flag=1;		
																	set flagtype =1;	
																else
																	 set flag=1;    -- 记录有找到
																	 set flagtype=0; -- 值异常，未找到重量对应数据
																end if;	
															else
																 select id into headid from tmp_pol_cust_special where find_in_set(destination1,destination1);
																	if headid<>0 then
																		call countfare_weight_get(currentUserId,headid,6,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
																		if flagweight=1 then
																			set flag=1;		
																			set flagtype =1;	
																		else
																			 set flag=1;    -- 记录有找到
																			 set flagtype=0; -- 值异常，未找到重量对应数据
																		end if;	
																	else
																		 set flag=0;
																		 set flagtype =1;
																		 set flagerrmsg='在国内客户个别特殊政策中有此单据对应的重复运价政策，请确认运价后进行开单！';
																	end if;
															end if;
												end if;			
										end if;
								 end if; 
							end if;
					
				     	end if; --  客户个别特殊政策查找完毕		
					 -- 判断客户的分组政策  pol_domestic_cus_group  pol_domestic_cus_group_head
			 if (flag=0 && flagtype=0) then
			 		-- 找单头
					 drop table if exists tmp_pol_cust_group;
					 create temporary table tmp_pol_cust_group
										select pol.* from pol_domestic_cus_group_head pol,base_customer cus
											where pol.port_city_id=baseAirport 
												and (pol.airway_id='ALL' or pol.airway_id=airlineId1)
												and (pol.arrive_city_id='ALL' or find_in_set(destination1,pol.arrive_city_id))
												and (pol.flight_id='ALL' or 
															((pol.flightType=1 and find_in_set(flightNo1,pol.flight_id)) or (pol.flightType=2 and !find_in_set(flightNo1,pol.flight_id)))
													 )
												 and (pol.start_date is null or  
															 flighDate between date_format(pol.start_date,'%Y-%m-%d') and  if ( pol.end_date is null , '9999-12-31',date_format(end_date,'%Y-%m-%d')) 
															)	
												 and pol.group_id=cus.GCODE
												 and cus.id=customerId
												 and pol.status=1
												 and pol.is_del=0;
												 
							select count(*) into nocount from  tmp_pol_cust_group;		
					
			       -- select  nocount;
							if nocount<>0 then   -- 有找到符合记录
							
								 if (nocount=1) then
										select id into headid from tmp_pol_cust_group;   -- 得到头id 以便后面取得单身生量等级资料		
									 select headid;
								    call countfare_weight_get(currentUserId,headid,5,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
									 select "aaaa";	
										
										if flagweight=1 then
											set flag=1;		
											set flagtype =1;	
											
											
											-- select customerRate;
											-- select minMoney;
										else
										   set flag=1;    -- 记录有找到
											 set flagtype=0; -- 值异常，未找到重量对应数据
									  end if;	
								 else  -- 如果有多条记录存在时，按 具体航班号 、航空公司 、具体货物品名 具体到站地点 的优先顺序取值 
									
										select id into headid from tmp_pol_cust_group where find_in_set(flightNo1,flight_id);
										
										-- select headid;
										
										if headid<>0 then
											 call countfare_weight_get(currentUserId,headid,5,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
												if flagweight=1 then
													set flag=1;		
													set flagtype =1;	
												else
													 set flag=1;    -- 记录有找到
													 set flagtype=0; -- 值异常，未找到重量对应数据
												end if;	
										else
											 select id into headid from tmp_pol_cust_group where find_in_set(airlineId1,airlineId1);
												if headid<>0 then
													call countfare_weight_get(currentUserId,headid,5,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
													if flagweight=1 then
														set flag=1;		
														set flagtype =1;	
													else
														 set flag=1;    -- 记录有找到
														 set flagtype=0; -- 值异常，未找到重量对应数据
													end if;	
												else								
														select id into headid from tmp_pol_cust_group where find_in_set(cargoType,CARGO_TYPE);
														 if headid<>0 then
																call countfare_weight_get(currentUserId,headid,5,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
																if flagweight=1 then
																	set flag=1;		
																	set flagtype =1;	
																else
																	 set flag=1;    -- 记录有找到
																	 set flagtype=0; -- 值异常，未找到重量对应数据
																end if;	
															else
																 select id into headid from tmp_pol_cust_group where find_in_set(destination1,destination1);
																	if headid<>0 then
																		call countfare_weight_get(currentUserId,headid,5,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
																		if flagweight=1 then
																			set flag=1;		
																			set flagtype =1;	
																		else
																			 set flag=1;    -- 记录有找到
																			 set flagtype=0; -- 值异常，未找到重量对应数据
																		end if;	
																	else
																		 set flag=0;
																		 set flagtype =1;
																		 set flagerrmsg='在国内客户分组政策中有此单据对应的重复运价政策，请确认运价后进行开单！';
																	end if;
															end if;
												end if;			
										end if;
								 end if; 
							end if;
					
			 
			         end if;
			 			 -- 判断客户总体政策  pol_domestic_cus_commons  pol_domestic_cus_commons_head
			 if (flag=0 && flagtype=0) then
			 		 		-- 找单头
					 drop table if exists tmp_pol_cust_commons;
					 create temporary table tmp_pol_cust_commons
											select * from pol_domestic_cus_commons_head 
											where port_city_id=baseAirport 
												and (airway_id='ALL' or airway_id=airlineId1)
												and (arrive_city_id='ALL' or find_in_set(destination1,arrive_city_id))
												and (flight_id='ALL' or 
															((flightType=1 and find_in_set(flightNo1,flight_id)) or (flightType=2 and !find_in_set(flightNo1,flight_id)))
													 )
												 and (start_date is null or  
															 flighDate between date_format(start_date,'%Y-%m-%d') and  if ( end_date is null , '9999-12-31',date_format(end_date,'%Y-%m-%d')) 
															)	
												 and status=1
												 and is_del=0;
												 
												 
							select count(*) into nocount from  tmp_pol_cust_commons;		
					
			 -- select  nocount;
							if nocount<>0 then   -- 有找到符合记录
							
								 if (nocount=1) then
										select id into headid from tmp_pol_cust_commons;   -- 得到头id 以便后面取得单身生量等级资料		
									 -- select headid;
								    call countfare_weight_get(currentUserId,headid,4,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
								-- select alertmessage;	
										
										if flagweight=1 then
											set flag=1;		
											set flagtype =1;	
											
											
											-- select customerRate;
											-- select minMoney;
										else
										   set flag=1;    -- 记录有找到
											 set flagtype=0; -- 值异常，未找到重量对应数据
									  end if;	
								 else  -- 如果有多条记录存在时，按 具体航班号 、航空公司 、具体货物品名 具体到站地点 的优先顺序取值 
									
										select id into headid from tmp_pol_cust_commons where find_in_set(flightNo1,flight_id);
										
										-- select headid;
										
										if headid<>0 then
											 call countfare_weight_get(currentUserId,headid,4,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
												if flagweight=1 then
													set flag=1;		
													set flagtype =1;	
												else
													 set flag=1;    -- 记录有找到
													 set flagtype=0; -- 值异常，未找到重量对应数据
												end if;	
										else
											 select id into headid from tmp_pol_cust_commons where find_in_set(airlineId1,airlineId1);
												if headid<>0 then
													call countfare_weight_get(currentUserId,headid,4,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
													if flagweight=1 then
														set flag=1;		
														set flagtype =1;	
													else
														 set flag=1;    -- 记录有找到
														 set flagtype=0; -- 值异常，未找到重量对应数据
													end if;	
												else								
														select id into headid from tmp_pol_cust_commons where find_in_set(cargoType,CARGO_TYPE);
														 if headid<>0 then
																call countfare_weight_get(currentUserId,headid,4,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
																if flagweight=1 then
																	set flag=1;		
																	set flagtype =1;	
																else
																	 set flag=1;    -- 记录有找到
																	 set flagtype=0; -- 值异常，未找到重量对应数据
																end if;	
															else
																 select id into headid from tmp_pol_cust_conmons where find_in_set(destination1,destination1);
																	if headid<>0 then
																		call countfare_weight_get(currentUserId,headid,4,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
																		if flagweight=1 then
																			set flag=1;		
																			set flagtype =1;	
																		else
																			 set flag=1;    -- 记录有找到
																			 set flagtype=0; -- 值异常，未找到重量对应数据
																		end if;	
																	else
																		 set flag=0;
																		 set flagtype =1;
																		 set flagerrmsg='在国内客户分组政策中有此单据对应的重复运价政策，请确认运价后进行开单！';
																	end if;
															end if;
												end if;			
										end if;
								 end if; 
							end if;
					
			 
			 end if;
			 
		-- select flag;
		-- select flagtype;
		-- select flagerrmsg;
			 if (flag=0 && flagtype=0) then
			 
			     set flagerrmsg='无相符的运价政策，请查核！！';					 
			 
			 end if ;
			 if (flag=1 && flagtype=1) then
			 -- select concat("aa",airlineId2);
			   -- if  ( airlineId2 is not null) then
				if  !(ISNULL(airlineId2) || LENGTH(trim(airlineId2))<1) then 
					
					    set flagerrmsg= concat(flagerrmsg,'注意: 本单有第二航程，并非同航空公司，请注意价各费率');
					
					end if;
			 
			 end if;
			 
	-- ---------------------------------------------------------------------------------------------------------------------------------
	-- 中转运价
	-- --------------------------------------------------------------------------------------------------------------------------------- 		
	else  -- 进行中转运作政策查找  如果此航空公司无中转运价政策还是要回头去找第一航程运价的第一段运价政策，提示手工修改
	   
		 -- 找中转运价单头
					 drop table if exists tmp_pol_cust_zz;
					 create temporary table tmp_pol_cust_zz 
										select * from pol_domestic_cus_zz_head 
											where port_city_id=baseAirport 
												and (airway_id='ALL' or airway_id=airlineId1)
												and (arrive_city_id='ALL' or find_in_set(destination1,arrive_city_id))
												and (second_arrive_city_id='ALL' or find_in_set(destination2,second_arrive_city_id))
												and (flight_id='ALL' or 
															((flightType=1 and find_in_set(flightNo1,flight_id)) or (flightType=2 and !find_in_set(flightNo1,flight_id)))
													 )
												 and (start_date is null or  
															 flighDate between date_format(start_date,'%Y-%m-%d') and  if ( end_date is null , '9999-12-31',date_format(end_date,'%Y-%m-%d')) 
															)	
												 and status=1
												 and is_del=0;
												 
							select count(*) into nocount from  tmp_pol_cust_zz;		
		 	 select  nocount;
							if nocount<>0 then   -- 有找到符合记录
							
								 if (nocount=1) then
										select id into headid from tmp_pol_cust_zz;   -- 得到头id 以便后面取得单身生量等级资料		
									-- select headid;
								    call countfare_weight_get(currentUserId,headid,7,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
									-- select "aaaa";	
										
										if flagweight=1 then
											set flag=1;		
											set flagtype =1;	
											
											
											-- select customerRate;
											-- select minMoney;
										else
										   set flag=1;    -- 记录有找到
											 set flagtype=0; -- 值异常，未找到重量对应数据
									  end if;	
								 else  -- 如果有多条记录存在时，按 具体航班号 、航空公司 、具体货物品名 具体到站地点 的优先顺序取值 
									
										select id into headid from tmp_pol_cust_zz where find_in_set(flightNo1,flight_id);
										
										-- select headid;
										
										if headid<>0 then
											 call countfare_weight_get(currentUserId,headid,7,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
												if flagweight=1 then
													set flag=1;		
													set flagtype =1;	
												else
													 set flag=1;    -- 记录有找到
													 set flagtype=0; -- 值异常，未找到重量对应数据
												end if;	
										else
											 select id into headid from tmp_pol_cust_zz where find_in_set(airlineId1,airlineId1);
												if headid<>0 then
													call countfare_weight_get(currentUserId,headid,7,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
													if flagweight=1 then
														set flag=1;		
														set flagtype =1;	
													else
														 set flag=1;    -- 记录有找到
														 set flagtype=0; -- 值异常，未找到重量对应数据
													end if;	
												else								
														select id into headid from tmp_pol_cust_zz where find_in_set(cargoType,CARGO_TYPE);
														 if headid<>0 then
																call countfare_weight_get(currentUserId,headid,7,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
																if flagweight=1 then
																	set flag=1;		
																	set flagtype =1;	
																else
																	 set flag=1;    -- 记录有找到
																	 set flagtype=0; -- 值异常，未找到重量对应数据
																end if;	
															else
																 select id into headid from tmp_pol_cust_zz where find_in_set(destination1,destination1);
																	if headid<>0 then
																		call countfare_weight_get(currentUserId,headid,7,weight,customerRate,minMoney,flagweight,flagerrmsg,alertflag,alertmessage,nowweight,autochange);	
																		if flagweight=1 then
																			set flag=1;		
																			set flagtype =1;	
																		else
																			 set flag=1;    -- 记录有找到
																			 set flagtype=0; -- 值异常，未找到重量对应数据
																		end if;	
																	else
																		 set flag=0;
																		 set flagtype =1;
																		 set flagerrmsg='在客户中转政策中有此单据对应的重复运价政策，请确认运价后进行开单！';
																	end if;
															end if;
												end if;			
										end if;
								 end if; 
							end if;
					
	    		
	   		-- select flag;
		-- select flagtype;
		-- select flagerrmsg;
			 if (flag=0 && flagtype=0) then
			 
			     set flagerrmsg='无相符的中转运价政策，请查核！！';					 
			 
			 end if ;
			
	
	end if;

  if (flag=0 || flagtype=0) then  -- 只有一个标识是有问题 则都要返回不成功
	
	    set flag=0;
	
	end if;



END;

