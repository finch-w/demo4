create function get_children_dep(department_id varchar(200)) returns varchar(20000)
BEGIN
-- 传入参数 department_id 
-- 根据传入参数找出其下级包括本身的所有部门id
DECLARE out_dep_id varchar(20000);
DECLARE out_dep_child varchar(20000);
declare flag tinyint(1) default 0;

SET out_dep_id = '';
SET out_dep_child = CAST(department_id AS CHAR);

WHILE out_dep_child IS NOT NULL
DO
if flag=0 then 
    SET out_dep_id=out_dep_child;
    set flag=1;

ELSE

    SET out_dep_id = CONCAT(out_dep_id,',',out_dep_child);
end if;
SELECT GROUP_CONCAT(outdep.dep_Id) INTO out_dep_child FROM 
(select cur.id dep_id,cur.name dep_name,par.id par_dep_id ,cur.PARENT par_dep_name
from qx_department cur,qx_department par where cur.parent=par.NAME
) outdep
 WHERE FIND_IN_SET(par_dep_id,out_dep_child) > 0;
END WHILE;
RETURN out_dep_id ;
END;

