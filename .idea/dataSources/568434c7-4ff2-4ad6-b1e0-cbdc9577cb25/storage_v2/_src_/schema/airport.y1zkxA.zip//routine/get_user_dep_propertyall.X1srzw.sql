create function get_user_dep_propertyall(user_dep_id varchar(32)) returns tinyint(1)
BEGIN
		#Routine body goes here...
-- 传入当前部门id ,取得其部门及其各下级部门负责出港，进港业务的合集，都包括为通用
 declare property integer default 8 ;  -- 存取循环值 
 declare property_0 integer default 0;
 declare property_1 integer default 0;
 declare property_2 integer default 0;
 declare  propertyall integer default 3; -- 得到最后值 3为出错
 declare no_more integer DEFAULT 0;



  DECLARE property_list CURSOR FOR   select distinct a.property from qx_department a where FIND_IN_SET(a.id,get_children_dep(user_dep_id));
 --       select distinct a.property  from qx_department a ,(select get_children_dep(user_dep_id) department_id from dual ) b   where FIND_IN_SET(a.id,b.department_id);



-- select distinct property from qx_department where FIND_IN_SET(id,get_children_dep(user_dep_id));
 
   DECLARE CONTINUE HANDLER FOR NOT FOUND  SET no_more = 1;
   
   OPEN property_list;
  
   FETCH property_list INTO property;


	if no_more = 1 then 
			 RETURN 3; 

	 ELSE

			  WHILE !no_more DO


            if property=0 THEN set property_0=1; end if;
            if property=1 then set property_1=1; end if;
            if property=2 then set property_2=1; end if;   

					set no_more=0; -- 防mysql bug
					FETCH property_list INTO property;


				
				 END WHILE;
				 CLOSE property_list;
   end if;	

  if (property_2=1) then set propertyall=2; end if;
	if (property_2=0 && property_0=0 && property_1=1) then set propertyall=1; end if;
	if (property_2=0 && property_0=1 && property_1=0) then set propertyall=0; end if;
	if (property_2=0 && property_0=1 && property_1=1) then set propertyall=2; end if;

    
	

	RETURN propertyall ;
END;

