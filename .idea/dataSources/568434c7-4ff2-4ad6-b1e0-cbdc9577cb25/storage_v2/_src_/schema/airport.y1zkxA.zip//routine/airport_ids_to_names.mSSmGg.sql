create function airport_ids_to_names(airport_ids varchar(10000), split_sign varchar(2)) returns varchar(5000)
BEGIN
	
	
	declare airport_names varchar(5000) default '';
	declare splits_no varchar(32);
	declare splits_name varchar(255) default '';
	declare i integer default 0;

	while(instr(airport_ids,split_sign)<>0) DO	
	
	
		 set splits_no = substring(airport_ids,1,instr(airport_ids,split_sign)-1);	
	    
			select cname_short	into splits_name from base_airport  where id=splits_no;
						
				
					
					if  (!(ISNULL(splits_name) || LENGTH(trim(splits_name))<1)) then
							   
								 if i=0 
								         then 
								             set  airport_names = splits_name;
														 set i=1;
								  else     
									       set airport_names= CONCAT(airport_names,',',splits_name);												 
												      
								  end if;
							
							end if;	
	
	    set airport_ids = INSERT(airport_ids,1,instr(airport_ids,split_sign),'');
	
	END WHILE;
	 select cname_short into splits_name from base_airport  where id=airport_ids;
	
	if  i=0
     	then 
			 
			  set airport_names= splits_name;	
	    else
	     set airport_names= CONCAT(airport_names,',',splits_name);	
			end if; 
	
	    -- insert into ls (ff) values (goods_type_names); 

	RETURN airport_names;
END;

