create function flight_longtext_to_String(flight_nos varchar(10000)) returns varchar(10000)
BEGIN
	declare flight_names varchar(10000);
	set flight_names=flight_nos;
	RETURN  flight_names;
END;

