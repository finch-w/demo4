create procedure customer_zc_group_insert()
BEGIN
-- 依据传入数据产生 客户分组运价政策
 DECLARE customer varchar(10);
 DECLARE goods_type varchar(6);
 DECLARE start_airport varchar(3);
 DECLARE end_airport LONGTEXT;


 declare  m double default 0 ;
 declare  n double;
 declare  A45 double;
 declare  A100 double;
 declare  A300 double;
 declare  A500 double;
 declare  A1000 double;

  declare airways  LONGTEXT;
  DECLARE flight_no longtext;


 declare i int default 0;

 declare j int default 0;

 declare k int default 0;




 declare no_more integer DEFAULT 0;
 declare num integer default 0;

 declare cnt_end_airport int ;
declare cnt int default 7;
declare cnt_airways int;


 
 declare  aairway_id varchar(255) ;-- '航空公司',
 declare  agt_id longtext ;-- '货物类型',  实际录入时是按一个货物类型导入
 declare  aflight_id longtext ;-- '航班',
 declare  aport_city_id varchar(255) ;-- '出港城市',
 declare  aarrive_city_id longtext ; -- '到港城市',
 declare  aarrive_city_id_ls longtext ; 
 declare  aweight_id varchar(255) ; -- '重量等级',
 declare  afeeRate double ;-- '费率',
 declare  astart_date datetime default DATE_FORMAT('2018-09-20','%Y-%m-%d');
 declare  aend_date datetime ;
  declare astatus int default 1 ; -- '状态码（有效1，无效0）',
 declare  ais_del tinyint default 0; -- '逻辑删除字段（1：已删除，0：未删除）',
 declare  acreateDate datetime default NOW(); 
 declare  amodifyDate datetime ;
 declare  acreate_user_id varchar(255) default '402881a84423645b014423854aa80001' ; 
 declare  amodify_user_id varchar(255) ;
 declare  agroup_id varchar(255) ; -- '客户分组',
 declare  aweight_type varchar(255) default '3'; -- '重量等级类别（1：航空公司类，2，配送类，3货代类）',
 declare  aflightType int(10) ; -- '航班标识（全部航班:''0''    适应航班:''1''''    不适应航班'':''2''）',



  

 DECLARE group_import CURSOR FOR  select * from pol_domestic_cus_group_import;
 
 DECLARE CONTINUE HANDLER FOR NOT FOUND  SET no_more = 1;

  
 OPEN group_import;
  
 FETCH group_import INTO customer,goods_type,start_airport,end_airport,n,A45,A100,A300,A500,A1000,airways,flight_no;

 
if no_more = 1 then 
     select "no result"; 

 ELSE
	 WHILE !no_more DO  
     -- airways      航空公司多个
      set cnt_airways = func_get_split_string_total(airways,",");-- 航空公司栏位只存一个

      select id into agt_id from base_goods_type where good_code=goods_type;
    -- flight_no    航班多个
    --  set cnt_flight_no = func_get_split_string_total(flight_no,","); -- 存于一行用航班代号不是id,不用转换
      set  aflight_id=flight_no;
      SELECT id into aport_city_id from base_airport where code_three=start_airport;     

    -- end_airport 目的港 多个
      set cnt_end_airport = func_get_split_string_total(end_airport,",");  -- 存于一行 id,  注意判断为空情况

      select id into agroup_id from base_customer_group where trim(code)=trim(customer);
      
      if aflight_id = '' then 
           set aflightType=0;
           set aflight_id='ALL';
      ELSE 
           set aflightType=1;           
      end if;

     
				while i < cnt_airways  do  -- 多个航空公司循环
		      set i = i + 1;

          select id into aairway_id from base_airways where replace(code_two,' ','')=replace( func_get_split_string(airways,',',i),' ','');

          set aarrive_city_id = '';
			     while j< cnt_end_airport do -- 多个目的港循环
             set j=j+1;

              select id into aarrive_city_id_ls from base_airport where replace(code_three,' ','')=replace( func_get_split_string(end_airport,',',i),' ','');
              
              if j=1 then
                set aarrive_city_id= aarrive_city_id_ls;
               ELSE
                 set aarrive_city_id=CONCAT(aarrive_city_id,aarrive_city_id_ls);-- j=1时因有一个为空不能用concat
               end if;

            end while;
            set j=0;
            
            set cnt = 7;
		
				 while k < cnt  do
						set k = k+ 1;
						
								 if k=1 then

												 select id into aweight_id from base_weight_level where type=aweight_type and code='M';
												 set afeerate=m;
								 end if;
								 if k=2 THEN
													
													 select id into aweight_id from base_weight_level where type=aweight_type and code='N';
													 set afeerate=n;
								 end if;
									if k=3 THEN
													select id into aweight_id from base_weight_level where type=aweight_type and code='+45';
													set afeerate=A45;
									end if;
									if k=4 THEN
													select id into aweight_id from base_weight_level where type=aweight_type and code='+100';
													set afeerate=A100;
									end if;
									if k=5 THEN
													select id into aweight_id from base_weight_level where type=aweight_type and code='+300';
													set afeerate=A300;
									 end if;
										if k=6 THEN
														select id into aweight_id from base_weight_level where type=aweight_type and code='+500';
														set afeerate=A500;

										end if;
										if k=7 then

														select id into aweight_id from base_weight_level where type=aweight_type and code='+1000';
														set afeerate=A1000;
										end if;

        -- insert into myls (f1,f2) VALUES( REPLACE(UUID(),'-',''),airways);
       
												insert into pol_domestic_cus_group_ls ( id,airway_id,gt_id,flight_id,port_city_id,arrive_city_id,
						weight_id,feerate,start_date,end_date,status,is_del,createdate,modifydate,create_user_id,modify_user_id,group_id,
					weight_type,flighttype)
												 values (REPLACE(UUID(),'-',''),aairway_id ,agt_id,aflight_id,aport_city_id ,aarrive_city_id,
              aweight_id,afeerate,astart_date,aend_date,astatus,ais_del,acreateDate,amodifyDate,acreate_user_id,amodify_user_id,agroup_id,
          aweight_type,aflightType);

          end WHILE;
          set k=0;

				end WHILE;

        set no_more=0; -- 防mysql bug
				FETCH group_import INTO customer,goods_type,start_airport,end_airport,n,A45,A100,A300,A500,A1000,airways,flight_no;
				set i=0;
	 END WHILE;
	 CLOSE group_import;
		-- select airways_id1;
end if;


END;

