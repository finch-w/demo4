create function goods_type_ids_to_names(goods_type_ids varchar(10000), split_sign varchar(2)) returns varchar(5000)
BEGIN
	
	
	declare goods_type_names varchar(5000) default '';
	declare splits_no varchar(32);
	declare splits_name varchar(255) default '';
	declare i integer default 0;

	while(instr(goods_type_ids,split_sign)<>0) DO	
	
	
		 set splits_no = substring(goods_type_ids,1,instr(goods_type_ids,split_sign)-1);	
	    
			select good_name into splits_name from base_goods_type  where id=splits_no;
						
				
					
					if  (!(ISNULL(splits_name) || LENGTH(trim(splits_name))<1)) then
							   
								 if i=0 
								         then 
								             set  goods_type_names = splits_name;
														 set i=1;
								  else     
									       set goods_type_names= CONCAT(goods_type_names,',',splits_name);												 
												      
								  end if;
							
							end if;	
	
	    set goods_type_ids = INSERT(goods_type_ids,1,instr(goods_type_ids,split_sign),'');
	
	END WHILE;
	 select good_name into splits_name from base_goods_type  where id=goods_type_ids;
	
	if  i=0
     	then 
			 
			  set goods_type_names= splits_name;	
	    else
	     set goods_type_names= CONCAT(goods_type_names,',',splits_name);	
			end if; 
	
	    -- insert into ls (ff) values (goods_type_names); 

	RETURN goods_type_names;
END;

