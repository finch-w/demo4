create procedure testprod(IN fin1 varchar(100), IN fin2 varchar(100), OUT fout1 double, OUT fout2 double)
BEGIN
  
	set fout1= 100.1;
	set fout2=  4.5;

END;

